package xyz.parkh.doing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoingApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoingApplication.class, args);
	}

}
